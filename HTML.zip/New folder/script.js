// Simulate two databases as arrays
const database1 = [];
const database2 = [];

// Function to handle submitting the prompt
function submitPrompt(promptId) {
    const promptInput = document.getElementById(`user-prompt${promptId}`);
    const message = promptInput.value.trim();

    // Ensure prompt has content
    if (message === "") return;

    // Store message in the appropriate database
    if (promptId === '1') {
        database1.push(message);
    } else if (promptId === '2') {
        database2.push(message);
    }

    // Display message in the chat container
    const chatContainer = document.getElementById(`chat-container${promptId}`);
    const messageElement = document.createElement("div");
    messageElement.classList.add("user-message");
    messageElement.textContent = message;
    chatContainer.appendChild(messageElement);

    // Clear the input field
    promptInput.value = "";

    // Auto-scroll to the latest message
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

// Function to add a new assistant to the list
function addAssistant() {
    const assistantsList = document.getElementById("assistants");
    const currentCount = assistantsList.children.length;

    // Check if the count is less than 5 before adding a new assistant
    if (currentCount < 5) {
        const newAssistant = document.createElement("li");
        newAssistant.textContent = `Assistant ${currentCount + 1}`;
        
        // Create a delete button
        const deleteButton = document.createElement("button");
        deleteButton.textContent = "X";
        deleteButton.className = "delete-button"; // Add a class for styling
        deleteButton.onclick = function() {
            assistantsList.removeChild(newAssistant);
        };
        
        // Append the delete button to the new assistant
        newAssistant.appendChild(deleteButton);
        assistantsList.appendChild(newAssistant);
    } else {
        // If the count exceeds 5, open the subscription page
        window.open('subscription.html', '_blank');
    }
}

// Function to initialize the assistants list with event listeners
function initializeAssistants() {
    const assistantsList = document.getElementById("assistants");
    
    // Add event listeners to delete buttons already in the list
    Array.from(assistantsList.children).forEach(assistant => {
        const deleteButton = document.createElement("button");
        deleteButton.textContent = "X";
        deleteButton.className = "delete-button"; // Add a class for styling
        deleteButton.onclick = function() {
            assistantsList.removeChild(assistant);
        };
        assistant.appendChild(deleteButton);
    });
}

// Call the initialize function on DOM load
document.addEventListener('DOMContentLoaded', initializeAssistants);