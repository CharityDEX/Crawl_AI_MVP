document.getElementById('user-prompt').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevent new line

        const promptInput = document.getElementById('user-prompt').value;
        const apiKey = document.getElementById('api-key').value;

        // Redirect to main.html with the input data as URL parameters
        window.location.href = `index.html?prompt=${encodeURIComponent(promptInput)}&apiKey=${encodeURIComponent(apiKey)}`;
    }
});