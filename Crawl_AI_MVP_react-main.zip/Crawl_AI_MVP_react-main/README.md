Temporary Installation instructions:

Download html files and read the instructions for the GPT

<del>
1. Use the .bat file listed as "install.bat" in order to download the necessary dependencies
2. download te files onto your default directory tat is shown in the temrinal
3. cd New Folder
4. open your powershell/terminal and type in "jupyter notebook testing.ipynb"
5. click run all cells
</del>
